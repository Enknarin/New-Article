const db = firebase.firestore();
const taskContainer = document.getElementById('task-container');
const btn1 = document.getElementById('btn-one');
const btn2 = document.getElementById('btn-two');
const btn3 = document.getElementById('btn-tree');

let index;
btn1.addEventListener("click", function() {
    console.log("1 button");
    myFunction("1");
  });
btn2.addEventListener("click", function() {
    console.log("2 button");
    myFunction("2");
  });
btn3.addEventListener("click", function() {
    console.log("3 button");
    myFunction("3");
  });

function myFunction(index) {
    var docRef = db.collection('More').doc(index);
    docRef.get().then((doc) => {
    if(doc.exists){
        console.log("Document Data", doc.data());
        const task = doc.data();

        taskContainer.innerHTML = `
        <div> 
            <h3>${task.topic}</h3>
            <p>${task.blog}</p>
        </div>`
    }else{
        console.log("No Document");
    }
    }).catch((error) => {
        console.log("Error", error);
    })

  }