# Firebase Realtime Database For Web - Javascript
Build simple list member app with CRUD operation with firebase firestore and how to implement the real time database.

## screenshot
![React CRUD app](./project.png)

### Video Tutorial
[youtube](https://youtu.be/N3Fmwf8ylrs)